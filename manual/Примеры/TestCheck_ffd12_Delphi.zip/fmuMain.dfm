object fmMain: TfmMain
  Left = 0
  Top = 0
  Caption = 'Driver KKT Test'
  ClientHeight = 127
  ClientWidth = 372
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object lbl1: TLabel
    Left = 106
    Top = 8
    Width = 160
    Height = 13
    Caption = #1055#1088#1080#1084#1077#1088' '#1089#1086#1079#1076#1072#1085#1080#1103' '#1095#1077#1082#1072' '#1060#1060#1044' 1.2'
  end
  object btnCreateCheck: TButton
    Left = 50
    Top = 64
    Width = 273
    Height = 25
    Caption = #1057#1092#1086#1088#1084#1080#1088#1086#1074#1072#1090#1100' '#1095#1077#1082
    TabOrder = 0
    OnClick = btnCreateCheckClick
  end
  object btnShowProperties: TButton
    Left = 49
    Top = 32
    Width = 273
    Height = 25
    Caption = #1053#1072#1089#1090#1088#1086#1081#1082#1072' '#1089#1074#1086#1081#1089#1090#1074'...'
    TabOrder = 1
    OnClick = btnShowPropertiesClick
  end
end
