program TestCheck_ffd12;

uses
  Vcl.Forms,
  fmuMain in 'fmuMain.pas' {fmMain},
  DrvFRLib_TLB in 'DrvFRLib_TLB.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfmMain, fmMain);
  Application.Run;
end.
