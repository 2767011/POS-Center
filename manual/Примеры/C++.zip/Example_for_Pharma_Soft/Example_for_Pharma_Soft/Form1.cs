﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DrvFRLib;
using System.Threading;

namespace Example_for_Pharma_Soft
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Driver = new DrvFR();
            Driver.Password = 30;
        } DrvFR Driver;

        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Driver.ShowProperties();
        }

        private void button3_Click(object sender, EventArgs e)
        {
//Открываем чек.
            Driver.CheckType = 0;
            Driver.OpenCheck();
			/*
						Driver.GetECRStatus();

						//Передаем данные кассира, производившего продажу
						Driver.TagNumber = 1021;
						Driver.TagType = 7;
						Driver.TagValueStr = "Кассир Машенька";
						Driver.FNSendTag();

						//Печатаем на чеке произвольную информацию. Здесь можно организовать печать полного наименования товара, информации о скидке, полной стоимости товара.
						//При этом, печать только на чеке, в ОФД данные не передаются.

						//Первая позиция
						Driver.StringForPrinting = "Мазь 'Линимент бальзамический (по Вишневскому)'";
						Driver.PrintString();
						Driver.StringForPrinting = "Количество: 1 тюбик          Цена: =100.00";
						Driver.PrintString();
						Driver.StringForPrinting = "                           Скидка: = 10.00";
						Driver.PrintString();
						Driver.StringForPrinting = "                            ИТОГО: = 90.00";
						Driver.PrintString();
						Driver.StringForPrinting = "                                       [M]";
						Driver.PrintString();

						Driver.Quantity = 1;
						//Стоимость товара с учетом скидок и наценок.
						Driver.Price = 90;
						Driver.Summ1Enabled = false;
						Driver.Tax1 = 1;
						Driver.Department = 1;
						Driver.PaymentTypeSign = 4; //Признак способа расчета для ФФД 1.05: "Полный расчет"
						Driver.PaymentItemSign = 2; //Признак предмета расчета: "Услуга"
						//организация передачи наименования товарной позиции. Мах длинна не более 128 сим.
						Driver.StringForPrinting = "//" + "Мазь 'Линимент бальзамический (по Вишневскому)'"; // данное наименование товара на чеке НЕ печатается, но в ОФД передается.
						Driver.FNOperation();
						//Передача тега 1162 методом FNSendItemCodeData()
						Driver.MarkingType = 17485; // Тип маркировки: 44 4D; можно передать значение "3" - Лекарства. Драйвер выполнит конвертацию типа в соответствии с приказом ФНС №434 
						Driver.GTIN = "00000046206367";  //Передаем код GTIN: 14 символов
						Driver.SerialNumber = "A978112";  //Передаем серийный номер: 7 символов
						Driver.FNSendItemCodeData();
			*/
			//Передаем информацию о льготе в соответствии с описанием: 20190528-Format-zapisi-dannykh-o-vybytii-LP-v-FFD-v2_4

			Driver.TagNumber = 1084;   //Доп. реквизит пользователя
			Driver.FNBeginSTLVTag();

			int my_TagID = Driver.TagID;

			Driver.TagID = my_TagID;
			Driver.TagNumber = 1085;
			Driver.TagType = 7;
			Driver.TagValueStr = "mdlp3108805";
			Driver.FNAddTag();

			Driver.TagID = my_TagID;
			Driver.TagNumber = 1086;
			Driver.TagType = 7;
			Driver.TagValueStr = "ps45102&dnАБV492&&781&dd181110&sid71752852194630&";
			Driver.FNAddTag();

			Driver.FNSendSTLVTag();

/*
            //Вторая позиция
            Driver.StringForPrinting = "Витамины Аскорбиновые 'Из детства'";
            Driver.PrintString();
            Driver.StringForPrinting = "Количество: 1 упаковка       Цена: =150.00";
            Driver.PrintString();
            Driver.StringForPrinting = "                           Скидка: = 15.00";
            Driver.PrintString();
            Driver.StringForPrinting = "                           ИТОГО: = 135.00";
            Driver.PrintString();
			Driver.StringForPrinting = "                                       [M]";
			Driver.PrintString();
*/
            Driver.CheckType = 1;
            Driver.Quantity = 1;
            //Стоимость товара с учетом скидок и наценок.
            Driver.Price = 135;
            Driver.Summ1Enabled = false;
            Driver.Tax1 = 1;
            Driver.Department = 1;
            Driver.PaymentTypeSign = 4; //Признак способа расчета для ФФД 1.05: "Полный расчет"
            Driver.PaymentItemSign = 4; //Признак предмета расчета: "Услуга"
            //организация передачи наименования товарной позиции. Мах длинна не более 128 сим.
            Driver.StringForPrinting = "//" + "Витамины Аскорбиновые 'Из детства'"; // данное наименование товара на чеке НЕ печатается, но в ОФД передается.
            Driver.FNOperation();

			//Реализуем дробленку: 1/10 упаковки
			Driver.TagNumber = 1191;
			Driver.TagType = 7;
			Driver.TagValueStr = "mdlp1/10&";
			Driver.FNSendTagOperation();

			Driver.BarCode = "010173456789433921GPiOI99wtmAtM91002492/r+UHmeqRXXfjCTLC2j8MauSavTwXGF/kkzKpaKQ50ZNvoLatTkTeHfGO6vLvGtTlQP0c5MOk0X15Wp3JYp6KA==";
            Driver.FNSendItemBarcode();


            Driver.StringForPrinting = "ИТОГО СКИДКА ПО ЧЕКУ:..............= 25.00";
            Driver.PrintString();

            Driver.CheckSubTotal();
            decimal _Summ = Driver.Summ1;

            //Закрываем чек
            Driver.Summ1 = _Summ;
            Driver.Summ2 = 0;
            Driver.Summ3 = 0;
            Driver.Summ4 = 0;
            Driver.Summ5 = 0;
            Driver.Summ6 = 0;
            Driver.Summ7 = 0;
            Driver.Summ8 = 0;
            Driver.Summ9 = 0;
            Driver.Summ10 = 0;
            Driver.Summ11 = 0;
            Driver.Summ12 = 0;
            Driver.Summ13 = 0;
            Driver.Summ14 = 0;
            Driver.Summ15 = 0;
            Driver.Summ16 = 0;
            Driver.RoundingSumm = 0;
            Driver.TaxType = 1;
            Driver.StringForPrinting = "====================================================";
            Driver.FNCloseCheckEx();

        }

		private void button4_Click(object sender, EventArgs e)
		{
			//Открываем чек.
			Driver.CheckType = 0;
			Driver.OpenCheck();

			Driver.GetECRStatus();

			//Передаем данные кассира, производившего продажу
			Driver.TagNumber = 1021;
			Driver.TagType = 7;
			Driver.TagValueStr = "Кассир Машенька";
			Driver.FNSendTag();

			Driver.TagNumber = 1192;
			Driver.TagType = 7;
			Driver.TagValueStr = "mdlp";
			Driver.FNSendTag();

			//Передаем информацию о льготе в соответствии с описанием: 20190528-Format-zapisi-dannykh-o-vybytii-LP-v-FFD-v2_4

			Driver.TagNumber = 1084;   //Доп. реквизит пользователя
			Driver.FNBeginSTLVTag();

			int my_TagID = Driver.TagID;

			Driver.TagID = my_TagID;
			Driver.TagNumber = 1085;
			Driver.TagType = 7;
			Driver.TagValueStr = "mdlp";
			Driver.FNAddTag();

			Driver.TagID = my_TagID;
			Driver.TagNumber = 1086;
			Driver.TagType = 7;
			Driver.TagValueStr = "sid00000000195141&";
			Driver.FNAddTag();

			Driver.FNSendSTLVTag();

			Driver.Quantity = 1;
			//Стоимость товара с учетом скидок и наценок.
			Driver.Price = 5;
			Driver.Summ1Enabled = false;
			Driver.Tax1 = 2;
			Driver.Department = 1;
			Driver.PaymentTypeSign = 4; //Признак способа расчета для ФФД 1.05: "Полный расчет"
			Driver.PaymentItemSign = 2; //Признак предмета расчета: "Подакцизный товар"
			//организация передачи наименования товарной позиции. Мах длинна не более 128 сим.
			Driver.StringForPrinting = "Уголь активированный таб. 250мг №10 ФС.-Лексредства"; // данное наименование товара на чеке печатается и передается в ОФД.
			Driver.FNOperation();
			//Передача тега 1162 методом FNSendItemCodeData()
			/*			Driver.MarkingType = 17485; // Тип маркировки: 44 4D; можно передать значение "3" - Лекарства. Драйвер выполнит конвертацию типа в соответствии с приказом ФНС №434 
						Driver.GTIN = "04601669002600";  //Передаем код GTIN: 14 символов
						Driver.SerialNumber = "0000000005ZxJ";  //Передаем серийный номер: 7 символов
						Driver.FNSendItemCodeData();

			/*			Driver.Quantity = 1;
						//Стоимость товара с учетом скидок и наценок.
						Driver.Price = 135;
						Driver.Summ1Enabled = false;
						Driver.Tax1 = 1;
						Driver.Department = 1;
						Driver.PaymentTypeSign = 4; //Признак способа расчета для ФФД 1.05: "Полный расчет"
						Driver.PaymentItemSign = 2; //Признак предмета расчета: "Подакцизный товар"
						//организация передачи наименования товарной позиции. Мах длинна не более 128 сим.
						Driver.StringForPrinting = "Витамины Аскорбиновые 'Из детства'"; // данное наименование товара на чеке печатается и передается в ОФД.
						Driver.FNOperation();
			*/
			//Реализуем дробленку: 1/10 упаковки
			Driver.TagNumber = 1191;
			Driver.TagType = 7;
			Driver.TagValueStr = "mdlp";
			Driver.FNSendTagOperation();

//			Driver.BarCode = "010173456789433921GPiOI99wtmAtM91002492/r+UHmeqRXXfjCTLC2j8MauSavTwXGF/kkzKpaKQ50ZNvoLatTkTeHfGO6vLvGtTlQP0c5MOk0X15Wp3JYp6KA==";
//			Driver.FNSendItemBarcode();


			Driver.CheckSubTotal();
			decimal _Summ = Driver.Summ1;

			//Закрываем чек
			Driver.Summ1 = _Summ;
			Driver.Summ2 = 0;
			Driver.Summ3 = 0;
			Driver.Summ4 = 0;
			Driver.Summ5 = 0;
			Driver.Summ6 = 0;
			Driver.Summ7 = 0;
			Driver.Summ8 = 0;
			Driver.Summ9 = 0;
			Driver.Summ10 = 0;
			Driver.Summ11 = 0;
			Driver.Summ12 = 0;
			Driver.Summ13 = 0;
			Driver.Summ14 = 0;
			Driver.Summ15 = 0;
			Driver.Summ16 = 0;
			Driver.RoundingSumm = 0;
			Driver.TaxType = 2;
			Driver.StringForPrinting = "====================================================";
			Driver.FNCloseCheckEx();
		}

		private void button5_Click(object sender, EventArgs e)
		{
			//Открываем чек.
			Driver.CheckType = 0;
			Driver.OpenCheck();

			Driver.GetECRStatus();

			//Передаем данные кассира, производившего продажу
			Driver.TagNumber = 1021;
			Driver.TagType = 7;
			Driver.TagValueStr = "Кассир Машенька";
			Driver.FNSendTag();

			Driver.Quantity = 10;
			//Стоимость товара с учетом скидок и наценок.
			Driver.Price = 90;
			Driver.Summ1Enabled = false;
			Driver.Tax1 = 1;
			Driver.Department = 1;
			Driver.PaymentTypeSign = 4; //Признак способа расчета для ФФД 1.05: "Полный расчет"
			Driver.PaymentItemSign = 2; //Признак предмета расчета: "Подакцизный товар"
			//организация передачи наименования товарной позиции. Мах длинна не более 128 сим.
			Driver.StringForPrinting = "Маска лицевая для защиты дыхательных путей, одноразового (многоразового)использования"; // данное наименование товара на чеке печатается и передается в ОФД.
			Driver.FNOperation();
			//Передача тега 1162 методом FNSendItemCodeData()
			Driver.MarkingType = 17677; // Тип маркировки: 45h 08h;
			Driver.BarCode = "2400001323807";  //Передаем код СИЗ (формат EAN-13)
			Driver.FNSendItemCodeData();

			Driver.Quantity = 5;
			//Стоимость товара с учетом скидок и наценок.
			Driver.Price = 134.75M;
			Driver.Summ1Enabled = false;
			Driver.Tax1 = 1;
			Driver.Department = 1;
			Driver.PaymentTypeSign = 4; //Признак способа расчета для ФФД 1.05: "Полный расчет"
			Driver.PaymentItemSign = 2; //Признак предмета расчета: "Подакцизный товар"
			//организация передачи наименования товарной позиции. Мах длинна не более 128 сим.
			Driver.StringForPrinting = "перчатки смотровые (процедурные) из латекса гевеи, неопудренные, нестерильные"; // данное наименование товара на чеке печатается и передается в ОФД.
			Driver.FNOperation();

			Driver.BarCode = "2400001225408";
			Driver.FNSendItemBarcode();

			Driver.CheckSubTotal();
			decimal _Summ = Driver.Summ1;

			//Закрываем чек
			Driver.Summ1 = _Summ;
			Driver.Summ2 = 0;
			Driver.Summ3 = 0;
			Driver.Summ4 = 0;
			Driver.Summ5 = 0;
			Driver.Summ6 = 0;
			Driver.Summ7 = 0;
			Driver.Summ8 = 0;
			Driver.Summ9 = 0;
			Driver.Summ10 = 0;
			Driver.Summ11 = 0;
			Driver.Summ12 = 0;
			Driver.Summ13 = 0;
			Driver.Summ14 = 0;
			Driver.Summ15 = 0;
			Driver.Summ16 = 0;
			Driver.RoundingSumm = 0;
			Driver.TaxType = 1;
			Driver.StringForPrinting = "====================================================";
			Driver.FNCloseCheckEx();
		}

		private void button6_Click(object sender, EventArgs e)
		{
			Driver.FNBeginOpenSession();

			Driver.TagNumber = 1021;
			Driver.TagType = 7;
			Driver.TagValueStr = "Кассир Машенька";
			Driver.FNSendTag();

			Driver.FNOpenSession();
		}

		private void button7_Click(object sender, EventArgs e)
		{
			Driver.FNBeginCloseSession();

			Driver.TagNumber = 1021;
			Driver.TagType = 7;
			Driver.TagValueStr = "Кассир Машенька";
			Driver.FNSendTag();

  		    Driver.FNCloseSession(); //Здесь можно так же использовать старый метод PrintReportWithCleaning().
		}

		private void btn_Check_KM_FFD12_Click(object sender, EventArgs e)
		{


			Driver.CheckType = 0;
			Driver.OpenCheck();

/*			Driver.TagNumber = 1261;   //Доп. реквизит пользователя
			Driver.FNBeginSTLVTag();

			int my_TagID = Driver.TagID;

			Driver.TagID = my_TagID;
			Driver.TagNumber = 1262;
			Driver.TagType = 7;
			Driver.TagValueStr = "020";
			Driver.FNAddTag();

			Driver.TagID = my_TagID;
			Driver.TagNumber = 1263;
			Driver.TagType = 7;
			Driver.TagValueStr = "14.12.2018";
			Driver.FNAddTag();

			Driver.TagID = my_TagID;
			Driver.TagNumber = 1264;
			Driver.TagType = 7;
			Driver.TagValueStr = "1556";
			Driver.FNAddTag();

			Driver.TagID = my_TagID;
			Driver.TagNumber = 1265;
			Driver.TagType = 7;
			Driver.TagValueStr = "tm=mdlp&sid00000000113101";
			Driver.FNAddTag();

     		Driver.FNSendSTLVTag();
*/
			Driver.BarCode = "010460702776893521000000013JBSF91FFD092dGVzdGifC5FkjETjJhotf7m8rsjQHeoNyxcpaEIZfDQ=";
			Driver.ItemStatus = 2;
			Driver.CheckItemMode = 0;
			//организация работы с мерным кол-вом (теги 1291, 1292, 1293 и 1294)

			String TLVData;
			Driver.TLVDataHex = "";
			Driver.TagNumber = 2108;
			Driver.TagType = 0; // тип ttByte
			Driver.TagValueInt = 0;
			Driver.GetTagAsTLV();

			TLVData = Driver.TLVDataHex;
			Driver.TagNumber = 1023;
			Driver.TagType = 4; // тип FVLN
			Driver.TagValueFVLN = 1;
			Driver.GetTagAsTLV();

			TLVData = TLVData + Driver.TLVDataHex;
			Driver.TagNumber = 1291;
			Driver.TagType = 8; // тип ttSTLV
			Driver.FNBeginSTLVTag();

			Driver.TagNumber = 1293;
			Driver.TagType = 3; // тип ttVLN
			Driver.TagValueVLN = "1";
			Driver.FNAddTag();

			Driver.TagNumber = 1294;
			Driver.TagType = 3; // тип ttVLN
			Driver.TagValueVLN = "7";
			Driver.FNAddTag();

			Driver.TagNumber = 1291;
			Driver.TagType = 8; // тип ttSTLV
			Driver.GetTagAsTLV();

			TLVData = TLVData + Driver.TLVDataHex;
			//
			Driver.TLVDataHex = TLVData;
			Driver.FNCheckItemBarcode();

			Driver.FNAcceptMakringCode();

			Driver.Quantity = 1;
			Driver.MeasureUnit = 0;
			Driver.DivisionalQuantity = true;
			Driver.Numerator = Convert.ToString(1);
			Driver.Denominator = Convert.ToString(7);
			Driver.Price = 90;
			Driver.Summ1Enabled = false;
			Driver.Tax1 = 1;
			Driver.Department = 1;
			Driver.PaymentTypeSign = 4; //Признак способа расчета для ФФД 1.05: "Полный расчет"
			Driver.PaymentItemSign = 33; //Признак предмета расчета: "Подакцизный товар"
			//организация передачи наименования товарной позиции. Мах длинна не более 128 сим.
			Driver.StringForPrinting = "Л-тироксин 50 Берлин-Хеми тб 50мкг N 50"; // данное наименование товара на чеке печатается и передается в ОФД.
			Driver.FNOperation();

			Driver.TagNumber = 1262;
			Driver.TagType = 7;
			Driver.TagValueStr = "020";
			Driver.FNSendTagOperation();

			Driver.TagNumber = 1263;
			Driver.TagType = 7;
			Driver.TagValueStr = "14.12.2018";
			Driver.FNSendTagOperation();

			Driver.TagNumber = 1264;
			Driver.TagType = 7;
			Driver.TagValueStr = "1556";
			Driver.FNSendTagOperation();

			Driver.TagNumber = 1265;
			Driver.TagType = 7;
			Driver.TagValueStr = "tm=mdlp&sid00000000113101";
			Driver.FNSendTagOperation();

			Driver.BarCode = "010460702776893521000000013JBSF91FFD092dGVzdGifC5FkjETjJhotf7m8rsjQHeoNyxcpaEIZfDQ=";
			Driver.FNSendItemBarcode();

			Driver.Summ1 = 2000;
			Driver.Summ2 = 0;
			Driver.Summ3 = 0;
			Driver.Summ4 = 0;
			Driver.Summ5 = 0;
			Driver.Summ6 = 0;
			Driver.Summ7 = 0;
			Driver.Summ8 = 0;
			Driver.Summ9 = 0;
			Driver.Summ10 = 0;
			Driver.Summ11 = 0;
			Driver.Summ12 = 0;
			Driver.Summ13 = 0;
			Driver.Summ14 = 0;
			Driver.Summ15 = 0;
			Driver.Summ16 = 0;
			Driver.RoundingSumm = 0;
//			Driver.TaxType = 1;
			Driver.StringForPrinting = "=================================================================";
			Driver.FNCloseCheckEx();

		}

		private void button8_Click(object sender, EventArgs e)
		{
			   Driver.StringForPrinting = "Строка для печати";
			   Driver.FontType = 1;
			   Driver.PrintStringWithFont();

			   Thread.Sleep(500);

		       Driver.PrintReportWithoutCleaning();
		}

		private void button9_Click(object sender, EventArgs e)
		{
			Driver.StringForPrinting = "Строка для печати";
			Driver.FontType = 1;
			Driver.PrintStringWithFont();
			Driver.PrintReportWithoutCleaning();
		}

		private void button10_Click(object sender, EventArgs e)
		{

			Driver.StringForPrinting = "Строка для печати";
			Driver.FontType = 1;
			Driver.PrintStringWithFont();

			Driver.BarCode = "00CJCIZ.01HIBF";
			Driver.BarcodeType = 0;
			Driver.BarcodeAlignment = 0;
			Driver.BarWidth = 2;
			Driver.LineNumber = 30;
			Driver.PrintBarcodeText = 0;
			Driver.PrintBarcodeLine();
		}

		private void btn_CorrectionReceipt_Click(object sender, EventArgs e)
		{
		    Driver.CheckType = 0;
			Driver.FNOpenCheckCorrection();

			if(comboBox1.SelectedIndex == 0)
			{
				Driver.TagNumber = 1173;
				Driver.TagType = 0;
				Driver.TagValueInt = 0;
				Driver.FNSendTag();

				Driver.TagNumber = 1179;
				Driver.TagType = 7;
				Driver.TagValueStr = "2";
				Driver.FNSendTag();

				Driver.TagNumber = 1178;
				Driver.TagType = 6;
				Driver.TagValueDateTime = DateTime.Today; //Parse("2021.07.20"); 
				Driver.FNSendTag();
			} 
			else
			{
				Driver.TagNumber = 1173;
				Driver.TagType = 0;
				Driver.TagValueInt = 1;
				Driver.FNSendTag();

				Driver.TagNumber = 1179;
				Driver.TagType = 7;
				Driver.TagValueStr = "2";
				Driver.FNSendTag();

				Driver.TagNumber = 1178;
				Driver.TagType = 6;
				Driver.TagValueDateTime = DateTime.Today; //Parse("2021.07.20"); 
				Driver.FNSendTag();
			}

			Driver.Quantity = 1;
			Driver.MeasureUnit = 0;
			Driver.Price = 90;
			Driver.Summ1Enabled = false;
			Driver.Tax1 = 1;
			Driver.Department = 1;
			Driver.PaymentTypeSign = 4; //Признак способа расчета
			Driver.PaymentItemSign = 1; //Признак предмета расчета
			//организация передачи наименования товарной позиции. Мах длинна не более 128 сим.
			Driver.StringForPrinting = "Л-тироксин 50 Берлин-Хеми тб 50мкг N 50"; // данное наименование товара на чеке печатается и передается в ОФД.
			Driver.FNOperation();

			Driver.Summ1 = 90;
			Driver.Summ2 = 0;
			Driver.Summ3 = 0;
			Driver.Summ4 = 0;
			Driver.Summ5 = 0;
			Driver.Summ6 = 0;
			Driver.Summ7 = 0;
			Driver.Summ8 = 0;
			Driver.Summ9 = 0;
			Driver.Summ10 = 0;
			Driver.Summ11 = 0;
			Driver.Summ12 = 0;
			Driver.Summ13 = 0;
			Driver.Summ14 = 0;
			Driver.Summ15 = 0;
			Driver.Summ16 = 0;
			Driver.RoundingSumm = 0;
            Driver.TaxType = 1;
			Driver.StringForPrinting = "=================================================================";
			Driver.FNCloseCheckEx();	
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}
    }
}
