﻿namespace Example_for_Pharma_Soft
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.btn_Check_KM_FFD12 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.button10 = new System.Windows.Forms.Button();
			this.btn_CorrectionReceipt = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(387, 298);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 0;
			this.button1.Text = "Закрыть";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(257, 298);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(115, 23);
			this.button2.TabIndex = 1;
			this.button2.Text = "Настройка свойств";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(12, 12);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(212, 23);
			this.button3.TabIndex = 2;
			this.button3.Text = "Чек с печатью доп. информации";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(231, 12);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(231, 23);
			this.button4.TabIndex = 4;
			this.button4.Text = "Чек простой";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(13, 41);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(212, 23);
			this.button5.TabIndex = 5;
			this.button5.Text = "Продажа СИЗ";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(13, 235);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(212, 23);
			this.button6.TabIndex = 6;
			this.button6.Text = "Открыть смену";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(14, 264);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(211, 23);
			this.button7.TabIndex = 7;
			this.button7.Text = "Закрыть смену";
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// btn_Check_KM_FFD12
			// 
			this.btn_Check_KM_FFD12.Location = new System.Drawing.Point(231, 40);
			this.btn_Check_KM_FFD12.Name = "btn_Check_KM_FFD12";
			this.btn_Check_KM_FFD12.Size = new System.Drawing.Size(231, 23);
			this.btn_Check_KM_FFD12.TabIndex = 8;
			this.btn_Check_KM_FFD12.Text = "Чек с КМ (ФФД1.2)";
			this.btn_Check_KM_FFD12.UseVisualStyleBackColor = true;
			this.btn_Check_KM_FFD12.Click += new System.EventHandler(this.btn_Check_KM_FFD12_Click);
			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(231, 204);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(231, 23);
			this.button8.TabIndex = 9;
			this.button8.Text = "Тест печати Х-отчета с задержкой 500мс";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// button9
			// 
			this.button9.Location = new System.Drawing.Point(231, 234);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(231, 23);
			this.button9.TabIndex = 10;
			this.button9.Text = "Тест печати Х-отчета без задержки";
			this.button9.UseVisualStyleBackColor = true;
			this.button9.Click += new System.EventHandler(this.button9_Click);
			// 
			// button10
			// 
			this.button10.Location = new System.Drawing.Point(231, 264);
			this.button10.Name = "button10";
			this.button10.Size = new System.Drawing.Size(231, 23);
			this.button10.TabIndex = 11;
			this.button10.Text = "Печать ШК CODE39";
			this.button10.UseVisualStyleBackColor = true;
			this.button10.Click += new System.EventHandler(this.button10_Click);
			// 
			// btn_CorrectionReceipt
			// 
			this.btn_CorrectionReceipt.Location = new System.Drawing.Point(6, 66);
			this.btn_CorrectionReceipt.Name = "btn_CorrectionReceipt";
			this.btn_CorrectionReceipt.Size = new System.Drawing.Size(195, 23);
			this.btn_CorrectionReceipt.TabIndex = 12;
			this.btn_CorrectionReceipt.Text = "Оформить";
			this.btn_CorrectionReceipt.UseVisualStyleBackColor = true;
			this.btn_CorrectionReceipt.Click += new System.EventHandler(this.btn_CorrectionReceipt_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.comboBox1);
			this.groupBox1.Controls.Add(this.btn_CorrectionReceipt);
			this.groupBox1.Location = new System.Drawing.Point(16, 71);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(207, 109);
			this.groupBox1.TabIndex = 13;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Чек коррекции (ФФД 1.2)";
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
            "0. Самостоятельная",
            "1. По предписанию"});
			this.comboBox1.Location = new System.Drawing.Point(6, 39);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(194, 21);
			this.comboBox1.TabIndex = 13;
			this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(3, 23);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(86, 13);
			this.label1.TabIndex = 14;
			this.label1.Text = "Тип коррекции:";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(474, 331);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.button10);
			this.Controls.Add(this.button9);
			this.Controls.Add(this.button8);
			this.Controls.Add(this.btn_Check_KM_FFD12);
			this.Controls.Add(this.button7);
			this.Controls.Add(this.button6);
			this.Controls.Add(this.button5);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Name = "Form1";
			this.Text = "Example";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button btn_Check_KM_FFD12;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.Button btn_CorrectionReceipt;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox comboBox1;
    }
}

